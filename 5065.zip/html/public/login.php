<div class="flexBotas bg-light">
<div class="container bg-light">
<div class="row">
  <div class="col-9 col-sm-5 col-md-4 mx-auto">
  <main class="form-signin">
  <form>
    <div class="caja_contenedora">
    <img src="views/app/images/iconos/tractor.png" alt="Logo" width="50" height="44" class="d-inline-block align-text-top tractor">
    <img src="views/app/images/iconos/sol.png" alt="Logo" width="50" height="50" class="d-inline-block align-text-top sol">
    <img src="views/app/images/iconos/avion.png" alt="Logo" width="50" height="50" class="d-inline-block align-text-top avion">
    
    </div>  
  
    <h1 class="h3 mb-3 fw-normal text-center maquina_escribir bg-primary">John Deere 5065E</h1>
    <div id="mensaje"></div>
    <div class="form-floating">
      <input type="email" class="form-control rounded-0 rounded-top "  placeholder="name@example.com" id="txt_email">
      <label for="floatingInput">Email</label>
    </div>
    <div class="form-floating">
      <input type="password" class="form-control rounded-0 rounded-bottom" placeholder="Password" id="txt_contrasena">
      <label for="floatingPassword">Contraseña</label>
    </div>

    <div class="checkbox mb-3 mt-3">
      <label>
        <input type="checkbox" value="remember-me"> Recordarme
      </label>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="button" onclick="iniciarSession()">Iniciar</button>




    <a class="btn btn-outline-info my-2" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button" aria-controls="offcanvasExample">
  ver
</a>

<div class="offcanvas offcanvas-start text-bg-light" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Bienvenido</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>Hola!</strong> en estos momentos no tenemos ordenes pendientes.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
    </div>
   
  </div>
</div>






    <p class="mt-5 mb-3 text-muted text-center">&copy;2022</p>
  </form>
</main>

  </div>
 
</div>
</div>
</div>