<?php 

echo '<div class="alert alert-danger" role="alert">
contenido no encontrado
</div>';