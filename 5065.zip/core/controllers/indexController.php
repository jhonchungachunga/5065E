<?php 
include (HTML_DIR.'/index/index.php');